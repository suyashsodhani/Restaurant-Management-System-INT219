
function abc(x) {
    x.style.background = "#E89E00";
}
 
function fn()
{
var x = document.getElementById("FN");
x.value=x.value.toUpperCase();
}

function fn2()
{
var x = document.getElementById("LN");
x.value=x.value.toUpperCase();
}

function sdf()
{
  x.style.background = "green";
}

function proceed()
{
var x = document.getElementById("FN").value;
var y = document.getElementById("LN").value;
if(x==""||y=="")
{
alert("KINDLY FILL ALL THE DETAILS");
}else
alert("hello "+x+" "+y+" successfully submited");
}

