function abc()
{
var a=prompt("confirm password");
if (a=="123")
window.open("staff.html");
else
alert("INVALID PASSWORD !!!!! NOT ALLOWED");
}

function xyz()
{
var a=prompt("confirm password");
if (a=="123")
window.open("account.html");
else
alert("INVALID PASSWORD !!!!! NOT ALLOWED");
}


function def()
{
var a=prompt("confirm password");
if (a=="123")
window.open("catering.html");
else
alert("INVALID PASSWORD !!!!! NOT ALLOWED");
}
